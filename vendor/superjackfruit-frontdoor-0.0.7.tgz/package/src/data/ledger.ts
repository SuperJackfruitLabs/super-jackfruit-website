import snapshot from './ledger.snapshot.json';
import { PRODUCTS, type Slug } from './products';

export interface PublicClaim {
  id: string;
  product: string;
  title: string;
  status: 'verified' | 'limited';
  caveat: string | null;
}

/** The public ledger, served by the suite worker at /captain/* on every product's own domain. */
export const ledgerUrl = (slug: Slug, origin?: string): string => `${origin ?? PRODUCTS[slug].url}/captain/ledger.json`;

const pub = (c: any): PublicClaim => ({
  id: String(c.id), product: String(c.product), title: String(c.title),
  status: c.status === 'limited' ? 'limited' : 'verified',
  caveat: c.caveat ?? null,
});

/** Claims for one product. Never throws; never carries evidence. */
export async function loadClaims(slug: Slug, opts: { fetch?: typeof fetch; origin?: string } = {}): Promise<PublicClaim[]> {
  const f = opts.fetch ?? globalThis.fetch;
  try {
    const res = await f(ledgerUrl(slug, opts.origin), { signal: AbortSignal.timeout(3000) });
    if (res.ok) {
      const body: any = await res.json();
      if (Array.isArray(body?.claims)) {
        return body.claims.filter((c: any) => c?.product === slug).map(pub);
      }
    }
  } catch {
    // fall through to the bundled snapshot
  }
  return (snapshot.claims as any[]).filter((c) => c.product === slug).map(pub);
}
