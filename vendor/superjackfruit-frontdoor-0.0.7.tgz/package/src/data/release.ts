import snapshot from './ledger.snapshot.json';
import { PRODUCTS, type Slug } from './products';

export interface Release { tag: string; url: string }

/** Latest release tag and link. Never throws; never requests a private (null) repo. */
export async function latestRelease(slug: Slug, opts: { fetch?: typeof fetch } = {}): Promise<Release> {
  const p = PRODUCTS[slug];
  const snap = (snapshot.releases as Record<string, { release: string }>)[slug]?.release ?? '';
  const fallback: Release = { tag: snap.split(',')[0].trim(), url: p.docs };
  if (!p.repo) return fallback;
  const f = opts.fetch ?? globalThis.fetch;
  try {
    const api = p.repo.replace('https://github.com/', 'https://api.github.com/repos/') + '/releases/latest';
    const res = await f(api, { signal: AbortSignal.timeout(3000), headers: { accept: 'application/vnd.github+json' } });
    if (res.ok) {
      const b: any = await res.json();
      if (typeof b?.tag_name === 'string' && typeof b?.html_url === 'string') return { tag: b.tag_name, url: b.html_url };
    }
  } catch {
    // fall through
  }
  return { tag: fallback.tag, url: `${p.repo}/releases` };
}
