// Runs in <head> before first paint (inlined by SuiteHead.astro, which fills in the product data).
// Ported from the prototype's frame-early.js, without the logo-motion dependency: the doorway
// draws a static mark, which the client upgrades to the brand motion after first paint. Sets the suite theme on <html> (the site's own data-theme
// and storage key, plus data-sjl-theme for the frame's tokens) and on every sjl-* host as the
// parser creates it.
(() => {
  const D = __SJL__;
  const slugOf = (href) => {
    try {
      const u = new URL(href);
      return Object.keys(D.products).find((s) => {
        const site = D.products[s].url;
        return u.origin === site || u.origin === site.replace('://', '://www.') || (/^(localhost|127\.0\.0\.1)$/.test(u.hostname) && +u.port === D.products[s].port);
      }) ?? null;
    } catch { return null; }
  };
  const html = document.documentElement;
  const mq = matchMedia('(prefers-color-scheme: light)');
  const me = D.products[D.here];
  // The theme logic is src/client/theme-core.js, inlined here by SuiteHead.astro.
  /*__THEME_CORE__*/
  const T = createTheme({
    site: { key: me.key, values: me.values },
    read: (k) => { try { return localStorage.getItem(k); } catch { return null; } },
    write: (k, v) => { try { v == null ? localStorage.removeItem(k) : localStorage.setItem(k, v); } catch {} },
    systemLight: () => mq.matches,
    paint(siteValue, t) {
      html.dataset.theme = siteValue;
      html.dataset.sjlTheme = t;
      document.querySelectorAll('sjl-suite-bar,sjl-product-header,sjl-claims,sjl-street').forEach((h) => h.setAttribute('data-sjl-theme', t));
    },
  });
  const carried = matchFragment(location.hash);
  if (carried) { T.set(carried); history.replaceState(null, '', location.pathname + location.search); } else T.apply();
  const effective = T.effective;
  mq.addEventListener('change', () => T.get() === 'system' && T.apply());
  // Frame hosts are parsed after this script: theme each one as it arrives, before it paints.
  const mo = new MutationObserver((list) => {
    for (const r of list) for (const n of r.addedNodes) {
      if (n.nodeType === 1 && n.localName.startsWith('sjl-')) n.setAttribute('data-sjl-theme', html.dataset.sjlTheme);
    }
  });
  mo.observe(html, { childList: true, subtree: true });
  addEventListener('DOMContentLoaded', () => { mo.disconnect(); T.apply(); }, { once: true });

  const still = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
  // The doorway is an element on <html> itself, so it can stand before <body> exists.
  // `logo` is the destination's mark when leaving (the client bundle carries all six); arriving,
  // it is this product's own mark, inlined here.
  function doorway(slug, logo) {
    const p = D.products[slug];
    const light = effective() === 'light';
    document.getElementById('sjl-doorway')?.remove();
    const d = document.createElement('div');
    d.id = 'sjl-doorway';
    d.setAttribute('aria-hidden', 'true');
    d.style.cssText = `position:fixed;inset:0;z-index:2147483647;pointer-events:none;display:grid;place-content:center;justify-items:center;gap:18px;will-change:opacity;background:radial-gradient(circle at 50% 46%,color-mix(in srgb,${p.color} ${light ? 22 : 30}%,transparent),transparent 62%),${light ? '#fbf8f4' : '#0d0c10'};color:${light ? '#1f1b18' : '#ece7e3'};font:600 19px/1.2 system-ui,-apple-system,'Segoe UI',sans-serif;letter-spacing:-.01em`;
    const mark = document.createElement('div');
    mark.style.cssText = 'width:72px;height:72px';
    mark.innerHTML = logo ?? (slug === D.here ? D.logo : '');
    const svg = mark.firstElementChild; if (svg) { svg.setAttribute('width', '72'); svg.setAttribute('height', '72'); }
    const label = document.createElement('div');
    label.textContent = p.name;
    d.append(mark, label);
    html.append(d);
    return {
      el: d,
      mark,
      fade(to, ms) {
        if (still()) ms = 0;
        return d.animate([{ opacity: to ? 0 : 1 }, { opacity: to ? 1 : 0 }], { duration: ms, easing: 'cubic-bezier(.4,0,.2,1)', fill: 'forwards' }).finished;
      },
      remove() { d.remove(); },
    };
  }

  const from = document.referrer ? slugOf(document.referrer) : null;
  const arrived = from && from !== D.here && !['reload', 'back_forward'].includes(performance.getEntriesByType?.('navigation')[0]?.type);
  let arrival = null;
  if (arrived) {
    arrival = doorway(D.here);
    // Never leave a visitor behind a doorway if the frame's client never loads.
    arrival.failsafe = setTimeout(() => {
      // The client claims the arrival (clearing this) as soon as it runs; firing means it never did.
      html.dataset.sjlFailsafe = '1';
      console.warn('[sjl-frame] client did not reveal arrival');
      arrival.fade(false, 300).then(() => arrival.remove());
    }, 1400);
  }
  window.__sjlFrameEarly = {
    slugOf, doorway, arrival, from: arrived ? from : null,
    theme: { get: T.get, set: T.set, effective, carry: T.carry },
  };
})();
