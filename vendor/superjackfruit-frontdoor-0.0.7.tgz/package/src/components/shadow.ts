// Helpers shared by the frame's server-rendered components. Each component builds its shadow
// root's inner HTML as a string and emits it inside <template shadowrootmode="open">.
import tokens from './styles/tokens.css?raw';
import jackSvg from '../brand/captain-jack.svg?raw';
import supermessage from '../brand/supermessage.svg?raw';
import superpipeline from '../brand/superpipeline.svg?raw';
import superlibrary from '../brand/superlibrary.svg?raw';
import superwitness from '../brand/superwitness.svg?raw';
import agentpod from '../brand/agentpod.svg?raw';
import salaam from '../brand/salaam.svg?raw';
import lab from '../brand/lab.svg?raw';
import { onColor, SITES, type Product, type Site } from '../data/products';

export const LOGOS: Record<Site, string> = { supermessage, superpipeline, superlibrary, superwitness, agentpod, salaam, lab };

export const esc = (s: string): string =>
  s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);

export const product = (slug: Site): Product => {
  const p = SITES[slug];
  if (!p) throw new Error(`frontdoor: unknown product "${slug}"`);
  return p;
};

/** Decorative copy of an SVG: no title/desc, hidden from assistive tech, sized by class. */
const decorative = (svg: string, cls: string): string =>
  svg.replace(/<\?xml[^>]*>/, '').replace(/<title[^>]*>[\s\S]*?<\/title>/, '').replace(/<desc[^>]*>[\s\S]*?<\/desc>/, '')
    .replace(/<svg\b([^>]*)>/, (_, a: string) => `<svg${a.replace(/\s(role|aria-label|aria-labelledby|width|height)="[^"]*"/g, '')} class="${cls}" aria-hidden="true" focusable="false">`)
    .trim();

/** Captain Jack, the delivered rig, drawn static. */
export const jack = (): string => decorative(jackSvg, 'jack');
export const logo = (slug: Site): string => decorative(LOGOS[slug], 'logo');

/** The opening of a shadow root: shared tokens, the product colours, the component's CSS. */
export const styles = (p: Product, css: string): string => {
  return `<style>${tokens}:host{--sjl-c:${p.color};--sjl-c-hi:${p.hi};--sjl-on-c:${onColor(p)}}${css}</style>`;
};

export const SUITE_URL = 'https://superjackfruit.com';
export const LEDGER_PAGE = 'https://github.com/SuperJackfruitLabs/sjl-marketing/blob/main/foundation/products.md';
