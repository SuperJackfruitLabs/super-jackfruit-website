// The procedural background behind the page, one motif per product (backdrop-core.js, ported
// unchanged from the prototype, SuperMessage's water at its tuned values). It follows the suite
// theme the head script sets on <html> as data-sjl-theme.
import { PRODUCTS, type Slug } from '../data/products';
import { mountBackdrop as core } from './backdrop-core.js';

const theme = (): 'light' | 'dark' => (document.documentElement.dataset.sjlTheme === 'light' ? 'light' : 'dark');

export function mountBackdrop(product: Slug): HTMLCanvasElement | null {
  if (!document.body || document.querySelector('canvas[data-sjl-backdrop]')) return null;
  const b = core({ product, color: PRODUCTS[product].color, theme });
  const canvas = document.body.querySelector<HTMLCanvasElement>(':scope > canvas[aria-hidden]');
  canvas?.setAttribute('data-sjl-backdrop', '');
  new MutationObserver(() => b.setTheme(theme())).observe(document.documentElement, { attributes: true, attributeFilter: ['data-sjl-theme'] });
  return canvas;
}
