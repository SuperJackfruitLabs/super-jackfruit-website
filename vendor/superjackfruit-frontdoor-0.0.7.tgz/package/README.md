# @superjackfruit/frontdoor 0.0.1

The Super Jackfruit Labs frame for Astro product sites (Astro 5 and 7): suite bar, product header, claims ("works on its own") and street, rendered into the page's HTML inside Declarative Shadow DOM so site CSS cannot reach it. It is complete without JavaScript; the client script only adds behaviour.

## Install

Vendored tarballs, like vibekit. In the site's `package.json`:

```json
"dependencies": {
  "@superjackfruit/frontdoor": "file:vendor/superjackfruit-frontdoor-0.0.1.tgz",
  "@superjackfruit/vibekit": "file:vendor/superjackfruit-vibekit-0.0.14.tgz"
}
```

vibekit is a peer dependency (`>=0.0.14 <0.1.0`), not bundled: a `file:` dependency inside a tarball does not resolve for consumers, and the site is meant to carry vibekit anyway. Astro is a peer (`>=5`).

## Use

```astro
---
import SuiteHead from '@superjackfruit/frontdoor/components/SuiteHead.astro';
import Frame from '@superjackfruit/frontdoor/components/Frame.astro';
---
<html lang="en">
  <head>
    ...
    <SuiteHead product="superlibrary" />
  </head>
  <body>
    <Frame product="superlibrary" cta={{ label: 'Get started', href: '/docs/install/' }}>
      <!-- the page body only -->
    </Frame>
  </body>
</html>
```

`product` is one of `supermessage`, `superpipeline`, `superlibrary`, `superwitness`, `agentpod`, `salaam`. `Frame` also takes optional `sections` and `links` (arrays of `{label, href}`) for the header nav and the street footer links. Other exports: `@superjackfruit/frontdoor/client`, `/data` (product registry), `/data/ledger.snapshot.json`, `/brand/*`.

`SuiteHead` goes in `<head>`: one small inline script sets the theme before first paint and handles the arriving doorway between products.

## What the site must remove

Its own header, footer and theme toggle (and any script that drives them). The frame owns all three. Keep the page's own `<main>` content inside `<Frame>`.

## Theme adapter

The frame writes the visitor's choice into the site's own storage and `data-theme`, so existing site CSS keeps working:

| Product | Storage key | Values |
| --- | --- | --- |
| supermessage | `sm-theme` | `light` / `dark` |
| salaam | `salaam-theme` | `paper` / `night` |
| the others | `theme` | `light` / `dark` |

## Captain Jack: the `/captain/*` route

The frame calls `/captain/...` on the site's own origin (same-origin, no CORS). The suite worker (`worker/`) must be routed at `/captain/*` on each product domain. Without it the Ask field answers with a pointer to the docs; the page itself is unaffected.

## No JavaScript

Everything is server-rendered: bar, header, claims, street, ledger-backed claims text. Without JS you lose the theme switch animation, the doorway, scroll reveals, Captain Jack's sheet and the street's motion; links and content remain.

## Build behaviour

At build time the frame tries two sources, each with a 3-second timeout: the site's own `/captain/ledger.json` (the live claims ledger) and the product's latest GitHub release (the version in the header). If either is unreachable it falls back to the bundled snapshot (`src/data/ledger.snapshot.json`) or the built-in version, so a build never fails because of them; on a slow or offline network it can add up to 3 seconds per source.

vibekit is a peer dependency (`>=0.0.14 <0.1.0`): the site installs it alongside this package, and `npm install` warns if the site's vibekit is outside that range. Tested on Astro 5 and Astro 7.

## Packing and verifying

From the repo root: `npm pack -w packages/frame --pack-destination .` gives `superjackfruit-frontdoor-0.0.1.tgz` (gitignored). The package ships `src/` (components, client, data, brand SVGs, vendored rig and logo motion) and this README; tests, fixture and e2e are excluded. The fixture imports by path; to verify a tarball, point the fixture's imports at `@superjackfruit/frontdoor/components/*`, add the two `file:` dependencies above, `npm install` in `fixture`, run `npm run e2e -w @superjackfruit/frontdoor`, then delete `fixture/node_modules`. Do not set `"sideEffects": false`: it is what dropped the rig script once.
