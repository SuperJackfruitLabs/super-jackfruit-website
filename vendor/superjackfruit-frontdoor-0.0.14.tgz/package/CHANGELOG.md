# Changelog

Earlier releases are described in their release commits and forge release notes.

## 0.0.14

- SuperDispatch and SuperExchange link their docs sites, https://docs.superdispatch.dev and https://docs.superexchange.dev, labelled "Docs" like the other products, in place of the GitHub README. Their llms.txt is now the docs site's (`/llms.txt`), not the landing page's.
- Captain Jack links both docs sites in his answers, and the suite worker reads their `/llms-full.txt` as a docs source. The worker change takes effect only when the worker is redeployed.
