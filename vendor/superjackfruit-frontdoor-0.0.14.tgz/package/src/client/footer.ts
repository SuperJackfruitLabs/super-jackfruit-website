// The footer's behaviour: visits remembered per site in localStorage 'sjl-seen' (plus the
// product the visitor came from) show as a small tick on each visited product, the releases
// link picks up a newer version, and the Ask Captain Jack button appears (it needs JavaScript).
import type { Site } from '../data/products';
import { liveRelease, releasedOn } from './release';

const SEEN = 'sjl-seen';

export function remember(here: Site, from: Site | null): Set<string> {
  let seen: string[] = [];
  try { const v = JSON.parse(localStorage.getItem(SEEN) ?? '[]'); if (Array.isArray(v)) seen = v.filter((s) => typeof s === 'string'); } catch { /* none */ }
  const set = new Set([...seen, ...(from ? [from] : []), here]);
  try { localStorage.setItem(SEEN, JSON.stringify([...set])); } catch { /* private mode */ }
  return set;
}

export function mountFooter(root: ShadowRoot, opts: { product: Site; from: Site | null; onAsk?: (question?: string) => void }): void {
  const seen = remember(opts.product, opts.from);
  root.querySelectorAll<HTMLElement>('a.tile[data-s]').forEach((t) => { if (seen.has(t.dataset.s ?? '')) t.classList.add('seen'); });

  const ask = root.getElementById('ask') as HTMLButtonElement | null;
  if (ask && opts.onAsk) {
    ask.hidden = false;
    ask.addEventListener('click', () => opts.onAsk?.());
  }

  const rel = root.getElementById('rel');
  if (rel) void liveRelease(opts.product).then((r) => {
    if (!r) return;
    rel.textContent = `Releases · ${r.tag}`;
    const on = releasedOn(r);
    if (on) rel.title = on;
  });
}
